import React, { useState } from 'react';

const CurrencyConverter = () => {
  // State variables to hold the amount and converted amount
  const [amount, setAmount] = useState('');
  const [convertedAmount, setConvertedAmount] = useState('');

  // Fixed exchange rate
  const exchangeRate = 0.85; // 1 USD = 0.85 EUR

  // Event handler for input change
  const handleInputChange = (event) => {
    setAmount(event.target.value);
  };

  // Event handler for conversion button click
  const handleConvert = () => {
    // Check if the input is a valid number
    if (!isNaN(parseFloat(amount))) {
      // Calculate the converted amount
      const result = parseFloat(amount) * exchangeRate;
      // Update the state with the converted amount rounded to 2 decimal places
      setConvertedAmount(result.toFixed(2));
    } else {
      // If input is not a valid number, show 'Invalid input'
      setConvertedAmount('Invalid input');
    }
  };

  return (
    <div>
      <h2>Currency Converter</h2>
      <div>
        <label>Enter amount in USD: </label>
        {/* Input field for amount with onChange event */}
        <input type="text" value={amount} onChange={handleInputChange} />
      </div>
      {/* Button to trigger conversion */}
      <button onClick={handleConvert}>Convert to EUR</button>
      {/* Display the converted amount if it exists */}
      {convertedAmount && (
        <div>
          <p>Converted amount: {convertedAmount} EUR</p>
        </div>
      )}
    </div>
  );
};

export default CurrencyConverter;
